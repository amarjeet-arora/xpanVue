<template>
   
</template>

<script>
export default {
  name: 'demo',
  props: {
    message: String
  }
}
</script>

 
<style >

</style>
