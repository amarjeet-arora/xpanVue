<template>
  <div class='row'>
    <div class= 'col-xs-12'>
      <header>
        <h1>Server Status</h1>
      </header>
    </div>
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>
