<template>
  <div class='row'>
    <div class= 'col-xs-12'>
      <footer>
       <p>All servers are managed here</p>
      </footer>
    </div>
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>
