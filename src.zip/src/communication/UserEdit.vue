<template>
<div class='component'>
  <h3>User can be edited here</h3>
  <p>Edit User</p>
</div>
</template>

<script>
export default {

}
</script>

<style scoped>
div {
  background-color: lightgreen;
}
</style>>

</style>
