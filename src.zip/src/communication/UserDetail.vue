<template>
<div class='component'>
  <h3>User details shown here</h3>
  <p>all the other details</p>
</div>
</template>

<script>
export default {

}
</script>

<style scoped>
div {
  background-color: lightcoral;
}
</style>>

</style>
