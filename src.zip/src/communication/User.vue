<template>
<div class='component'>
  <h3>User Parent Component</h3>
  <hr>
  <div class='row'>
    <div class= 'col-xs-12 col-sm-6'>
      <app-user-details></app-user-details>
    </div>
    <div class= 'col-xs-12 col-sm-6'>
      <app-user-edit></app-user-edit>
    </div>
  </div>
</div>
</template>

<script>
import UserDetails from './UserDetail.vue'
import UserEdit from './UserEdit.vue'
export default {

  components :{
    appUserDetails:UserDetails,
    appUserEdit:UserEdit
  }

}
</script>

<style scoped>
div {
  background-color: lightblue;
}
</style>>

</style>
